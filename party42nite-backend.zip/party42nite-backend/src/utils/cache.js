// Simple in-memory cache, shared across every request this server handles —
// this is the real fix for the quota problem the client-side cache could
// only patch over. One fetch from Google serves every user asking about
// roughly the same place, instead of one fetch per device.
//
// Limitation worth knowing: this cache lives in one server process's
// memory. If you scale to multiple server instances (needed well before
// you actually hit 1M concurrent users), each instance has its own cache —
// fine for a while, but the real fix at that point is a shared cache like
// Redis. Swapping this module for a Redis-backed one later doesn't require
// changing any route — they only call get/set below.

const store = new Map();

export function cacheGet(key) {
  const entry = store.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    store.delete(key);
    return null;
  }
  return entry.value;
}

export function cacheSet(key, value, ttlMs) {
  store.set(key, { value, expiresAt: Date.now() + ttlMs });

  // Basic bound so a long-running server doesn't grow unbounded.
  if (store.size > 5000) {
    const oldestKey = [...store.entries()].sort((a, b) => a[1].expiresAt - b[1].expiresAt)[0][0];
    store.delete(oldestKey);
  }
}
