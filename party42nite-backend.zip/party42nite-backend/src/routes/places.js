import { Router } from 'express';
import { cacheGet, cacheSet } from '../utils/cache.js';

const router = Router();
const PLACES_TTL_MS = 60 * 60 * 1000; // 1 hour — matches the client's old cache window

const NEARBY_URL = 'https://places.googleapis.com/v1/places:searchNearby';
const TEXT_URL = 'https://places.googleapis.com/v1/places:searchText';
const DETAILS_URL = 'https://places.googleapis.com/v1/places';

const FIELD_MASK = [
  'places.id', 'places.displayName', 'places.formattedAddress',
  'places.shortFormattedAddress', 'places.location', 'places.rating',
  'places.userRatingCount', 'places.types', 'places.primaryType',
  'places.businessStatus',
].join(',');

function cacheKeyFor(prefix, body) {
  // Stable stringify of the relevant fields — good enough for a cache key
  // since request shapes are simple and controlled by our own client.
  return `${prefix}:${JSON.stringify(body)}`;
}

// POST /api/places/nearby — body: { includedTypes, maxResultCount, locationRestriction }
router.post('/nearby', async (req, res) => {
  const key = cacheKeyFor('nearby', req.body);
  const cached = cacheGet(key);
  if (cached) return res.json(cached);

  try {
    const googleRes = await fetch(NEARBY_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': process.env.GOOGLE_API_KEY,
        'X-Goog-FieldMask': FIELD_MASK,
      },
      body: JSON.stringify(req.body),
    });
    const data = await googleRes.json();
    if (!googleRes.ok) return res.status(googleRes.status).json(data);
    cacheSet(key, data, PLACES_TTL_MS);
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: 'Upstream request failed' });
  }
});

// POST /api/places/text — body: { textQuery, maxResultCount, locationBias }
router.post('/text', async (req, res) => {
  const key = cacheKeyFor('text', req.body);
  const cached = cacheGet(key);
  if (cached) return res.json(cached);

  try {
    const googleRes = await fetch(TEXT_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': process.env.GOOGLE_API_KEY,
        'X-Goog-FieldMask': FIELD_MASK,
      },
      body: JSON.stringify(req.body),
    });
    const data = await googleRes.json();
    if (!googleRes.ok) return res.status(googleRes.status).json(data);
    cacheSet(key, data, PLACES_TTL_MS);
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: 'Upstream request failed' });
  }
});

// GET /api/places/:placeId/reviews
router.get('/:placeId/reviews', async (req, res) => {
  const { placeId } = req.params;
  const key = cacheKeyFor('reviews', placeId);
  const cached = cacheGet(key);
  if (cached) return res.json(cached);

  try {
    const googleRes = await fetch(`${DETAILS_URL}/${placeId}`, {
      headers: {
        'X-Goog-Api-Key': process.env.GOOGLE_API_KEY,
        'X-Goog-FieldMask': 'reviews',
      },
    });
    const data = await googleRes.json();
    if (!googleRes.ok) return res.status(googleRes.status).json(data);
    cacheSet(key, data, PLACES_TTL_MS);
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: 'Upstream request failed' });
  }
});

export default router;
