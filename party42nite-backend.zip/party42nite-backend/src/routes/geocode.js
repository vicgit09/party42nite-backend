import { Router } from 'express';
import { cacheGet, cacheSet } from '../utils/cache.js';

const router = Router();
const GEOCODE_TTL_MS = 24 * 60 * 60 * 1000; // a day — a place's coordinates don't change

// GET /api/geocode?address=...
router.get('/', async (req, res) => {
  const { address } = req.query;
  if (!address) return res.status(400).json({ error: 'Missing address param' });

  const key = `geocode:${address}`;
  const cached = cacheGet(key);
  if (cached) return res.json(cached);

  try {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${process.env.GOOGLE_API_KEY}`;
    const googleRes = await fetch(url);
    const data = await googleRes.json();
    if (!googleRes.ok) return res.status(googleRes.status).json(data);
    cacheSet(key, data, GEOCODE_TTL_MS);
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: 'Upstream request failed' });
  }
});

export default router;
