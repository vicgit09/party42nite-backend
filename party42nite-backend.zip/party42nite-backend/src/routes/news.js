import { Router } from 'express';
import { cacheGet, cacheSet } from '../utils/cache.js';

const router = Router();
const NEWS_TTL_MS = 15 * 60 * 1000; // 15 minutes — news actually changes

// GET /api/news?q=...&gl=US&hl=en
// Returns raw RSS XML — the client already knows how to parse this
// (fast-xml-parser), so the backend just needs to fetch and cache it.
// Bonus: this also fixes the web preview's CORS problem, since the
// server-to-server fetch isn't subject to browser CORS rules.
router.get('/', async (req, res) => {
  const { q, gl = 'US', hl = 'en' } = req.query;
  if (!q) return res.status(400).json({ error: 'Missing q param' });

  const key = `news:${q}:${gl}:${hl}`;
  const cached = cacheGet(key);
  if (cached) {
    res.set('Content-Type', 'application/xml');
    return res.send(cached);
  }

  try {
    const ceid = `${gl}:${hl}`;
    const params = new URLSearchParams({ q, hl: `${hl}-${gl}`, gl, ceid });
    const url = `https://news.google.com/rss/search?${params.toString()}`;
    const newsRes = await fetch(url);
    const xml = await newsRes.text();
    if (!newsRes.ok) return res.status(newsRes.status).send(xml);
    cacheSet(key, xml, NEWS_TTL_MS);
    res.set('Content-Type', 'application/xml');
    res.send(xml);
  } catch (e) {
    res.status(502).json({ error: 'Upstream request failed' });
  }
});

export default router;
