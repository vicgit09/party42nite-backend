import { Router } from 'express';
import { cacheGet, cacheSet } from '../utils/cache.js';

const router = Router();
const SPORTS_TTL_MS = 60 * 60 * 1000; // 1 hour — fixtures don't change that often

function sportsDbBase() {
  return `https://www.thesportsdb.com/api/v1/json/${process.env.SPORTSDB_KEY || '123'}`;
}

// GET /api/sports/fixtures/:leagueId
router.get('/fixtures/:leagueId', async (req, res) => {
  const { leagueId } = req.params;
  const key = `fixtures:${leagueId}`;
  const cached = cacheGet(key);
  if (cached) return res.json(cached);

  try {
    const sdbRes = await fetch(`${sportsDbBase()}/eventsnextleague.php?id=${leagueId}`);
    const data = await sdbRes.json();
    if (!sdbRes.ok) return res.status(sdbRes.status).json(data);
    cacheSet(key, data, SPORTS_TTL_MS);
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: 'Upstream request failed' });
  }
});

// GET /api/sports/search-league?sport=Rugby&contains=World Cup
router.get('/search-league', async (req, res) => {
  const { sport } = req.query;
  if (!sport) return res.status(400).json({ error: 'Missing sport param' });

  const key = `search-league:${sport}`;
  const cached = cacheGet(key);
  if (cached) return res.json(cached);

  try {
    const sdbRes = await fetch(`${sportsDbBase()}/search_all_leagues.php?s=${encodeURIComponent(sport)}`);
    const data = await sdbRes.json();
    if (!sdbRes.ok) return res.status(sdbRes.status).json(data);
    cacheSet(key, data, SPORTS_TTL_MS);
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: 'Upstream request failed' });
  }
});

export default router;
