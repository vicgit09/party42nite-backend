import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

import { requireAppSecret } from './middleware/auth.js';
import { apiLimiter } from './middleware/rateLimiter.js';
import placesRouter from './routes/places.js';
import geocodeRouter from './routes/geocode.js';
import sportsRouter from './routes/sports.js';
import newsRouter from './routes/news.js';

dotenv.config();

if (!process.env.GOOGLE_API_KEY || !process.env.APP_SHARED_SECRET) {
  console.error('Missing required environment variables — copy .env.example to .env and fill it in.');
  process.exit(1);
}

const app = express();
app.use(cors());
app.use(express.json());

// Every /api route requires the app secret and is rate-limited — this is
// what actually stops random internet traffic from running up your Google
// bill, unlike the old client-only setup where the key itself was the
// only (and completely exposed) gate.
app.use('/api', requireAppSecret, apiLimiter);

app.use('/api/places', placesRouter);
app.use('/api/geocode', geocodeRouter);
app.use('/api/sports', sportsRouter);
app.use('/api/news', newsRouter);

app.get('/health', (req, res) => res.json({ status: 'ok' }));

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Party42nite backend listening on port ${port}`);
});
