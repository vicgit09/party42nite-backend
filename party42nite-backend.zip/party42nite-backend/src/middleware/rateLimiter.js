import rateLimit from 'express-rate-limit';

// Per-IP limit. 100 requests per 15 minutes is generous for one real user
// browsing the app (the client-side cache means most of their taps don't
// even reach this server), while still capping what a single abusive
// source can do. Tune this once you have real traffic data — the right
// number depends on how chatty the app actually is per session.
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests — please slow down.' },
});
