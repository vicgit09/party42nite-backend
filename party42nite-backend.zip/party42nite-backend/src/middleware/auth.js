// Checks that the request came from your app (or at least someone who has
// the shared secret), not just anyone who found the backend's URL.
//
// Honest limit: this secret ships inside the app bundle too, so it CAN be
// extracted the same way the old Google key could. What it actually buys
// you: (1) it's not billed by Google directly — extracting it doesn't
// hand someone your Google Cloud bill, just access to your own rate-limited
// backend; (2) you can rotate it centrally (redeploy the backend) without
// needing everyone to update the app, unlike a key baked into shipped
// builds; (3) combined with the rate limiter, it meaningfully raises the
// cost of abuse even though it isn't cryptographically bulletproof.
// Upgrading to something stronger (Firebase App Check, signed requests
// with per-install keys) is a real next step once this app has enough
// traffic to be worth attacking specifically.
export function requireAppSecret(req, res, next) {
  const provided = req.header('X-App-Secret');
  if (!provided || provided !== process.env.APP_SHARED_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}
